﻿namespace BankAppGp;

public class Banco
{
    private readonly List<Cliente> _clientes;
    public IReadOnlyList<Cliente> Clientes => _clientes;

    private readonly List<Conta> _contas;
    public IReadOnlyList<Conta> Contas => _contas;

    // criar cliente:
    public void CriarCliente(string name, string cpf)
    {
        if (name == null || cpf == null)
        {
            throw new ArgumentNullException("Nome e CPF não podem ser nulos.");
        }

        foreach (var c in _clientes)
        {
            if (c.Cpf == cpf)
            {
                throw new ArgumentException("CPF já existe no cadastro.");
            }
        }

        var novoCliente = new Cliente(name, cpf);

        _clientes.Add(novoCliente);
    }

    // consultar cliente:
    public Cliente BuscarClientePorCpf(string cpf)
    {
        var cliente = _clientes.FirstOrDefault(c =>  c.Cpf == cpf);
        
        if (cliente == null)
        {
            throw new InvalidOperationException("Cliente não encontrado para este CPF.")
        }
        
        return cliente;
    }

    // criar conta:
    public ContaCorrente CriarContaCorrente(string cpf, decimal saldoInicial)
    {
        if (cpf == null)
        {
            throw new ArgumentNullException(nameof(cpf));
        }

        if (saldoInicial < 0)
        {
            throw new ArgumentException("Saldo inicial não pode ser negativo.");
        }

        Cliente cliente = BuscarClientePorCpf(cpf);

        var novaConta = new ContaCorrente(saldoInicial);
        cliente.AdicionarConta(novaConta);
        _contas.Add(novaConta);
        return novaConta;
    }

    public ContaPoupanca CriarContaPoupanca(string cpf, decimal saldoInicial)
    {
        if (cpf == null)
        {
            throw new ArgumentNullException(nameof(cpf));
        }

        if (saldoInicial < 0)
        {
            throw new ArgumentException("Saldo inicial não pode ser negativo.");
        }

        Cliente cliente = BuscarClientePorCpf(cpf);

        var novaConta = new ContaPoupanca(saldoInicial);
        cliente.AdicionarConta(novaConta);
        _contas.Add(novaConta);
        return novaConta;
    }

}