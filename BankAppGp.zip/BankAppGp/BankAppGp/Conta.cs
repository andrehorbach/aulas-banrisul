﻿namespace BankAppGp;

public  class Conta
{
    protected decimal _saldo;

    public decimal Saldo => _saldo;

    public Conta(decimal saldoInicial)
    {
        if (saldoInicial < 0)
            throw new ArgumentException("Saldo inicial não pode ser negativo.");

        _saldo = saldoInicial;
    }

    public void Depositar(decimal valor)
    {
        if (valor <= 0)
            throw new ArgumentException("Valor do depósito deve ser positivo!");

        _saldo += valor;
    }

    public virtual void Retirar(decimal valor) {
        if (valor <= 0) {
            throw new ArgumentException("Valor do saque deve ser positivo!");
        }
        
        if (valor > _saldo)
            throw new InvalidOperationException("Saldo insuficiente!");

        _saldo -= valor;
    }

    public void Transferir(Conta destino, decimal valor)
    {
        if (valor <= 0)
            throw new ArgumentException("Valor da transferência deve ser positivo!");

        if (destino == null)
            throw new ArgumentNullException(nameof(destino));

        Retirar(valor);
        destino.Depositar(valor);
    }
}

public class ContaCorrente : Conta
{
    public ContaCorrente(decimal saldoInicial) : base(saldoInicial)
    {

    }

}

public class ContaPoupanca : Conta
{
    public ContaPoupanca(decimal saldoInicial) : base(saldoInicial)
    {

    }
    public override void Retirar(decimal valor)
    {

        if (valor >= _saldo)
            throw new InvalidOperationException("Poupanca não permite saque total");

        base.Retirar(valor);
    }

}