﻿using System.Collections.Generic;

namespace BankAppGp
{
    public class Cliente
    {
        private readonly string _nome;
        private readonly string _cpf;
        private readonly List<Conta> _contas;
        public string Nome => _nome;
        public string Cpf => _cpf;
        public IReadOnlyList<Conta> Contas => _contas;

        public Cliente(string nome, string cpf)
        {
            if (string.IsNullOrWhiteSpace(nome)) throw new ArgumentException("Nome inválido.");
            _nome = nome;
            _cpf = cpf;
            _contas = new List<Conta>();
        }

        public void AdicionarConta(Conta conta)
        {
            if (conta == null)
            {
                throw new ArgumentNullException(nameof(conta));
            }
            _contas.Add(conta);
        }
    }
}