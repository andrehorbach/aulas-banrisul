﻿using System;

namespace BankAppGp
{ 


    class Program
    {
        static void Main(string[] args)
        {
            var banco = new Banco();
            banco.CriarCliente("André", "001");
            banco.CriarCliente("João", "002");

            var contaAndre = banco.CriarContaCorrente("001", 10000m);
            var contaJoao = banco.CriarContaPoupanca("002", 100m);


            Console.WriteLine($"Nome Pessoa p1 = ");


            foreach (var conta in p1.Contas)
            {
                Console.WriteLine($"Saldo conta = {conta.Saldo}");
            }

            foreach (var conta in p2.Contas)
            {
                Console.WriteLine($"Saldo conta = {conta.Saldo}");
            }

            //contaPoupanca1.Transferir(contaCorrente1, 4000);
            //Console.WriteLine($"Saldo c1 = {contaCorrente1.Saldo}");
            //Console.WriteLine($"Saldo c2 = {contaPoupanca1.Saldo}");


        }
    }
}